package devandroid.alves.applistacurso.applistacurso.model;

public class Curso {

    public  Curso(){}
}
